# Infinite Enchants (Minecraft Java 1.21.4 / Fabric)

This is a **buildable starter foundation**, not yet the complete feature list. It registers:
- Arcane Crystal item and crafting recipe
- Arcane Enchanting Altar block and crafting recipe
- English and Russian item names
- Fabric/Gradle project configuration for Java 21

The infinite-level enchantment engine, upgrade GUI/tree, persistent station progression, and the listed special enchantment effects are not implemented in this starter. Those systems need to be added and tested in separate steps; this project does not pretend they already work.

## Requirements
- Minecraft Java 1.21.4
- JDK 21
- Gradle (or add the Gradle wrapper from the official Fabric example project)
- IntelliJ IDEA Community Edition recommended

## Build
From this folder, run:

Windows:
```bat
gradle build
```

Linux/macOS:
```bash
gradle build
```

The output jar should appear under `build/libs/`. Install Fabric Loader for Minecraft 1.21.4 and place the remapped jar in the game's `mods` folder along with Fabric API for 1.21.4.

If Gradle cannot resolve a dependency, check the current 1.21.4 versions in the official Fabric version selector and update `gradle.properties`.

## Next implementation milestones
1. Custom persistent data for station tier and scalable enchantment levels.
2. Upgrade GUI and technology tree.
3. Server-authoritative mining handlers for 3x3 and vein mining with durability/drop safeguards.
4. Combat, magnet, autosmelt, farmer, and teleport effects.
5. Config file and in-game balancing controls.
6. Dedicated single-player survival testing and performance checks.

## Notes
- Back up worlds before testing mods.
- This mod is designed for single-player play, but its registry/content foundation uses normal Fabric entrypoints.
