package dev.infiniteenchants;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.block.AbstractBlock;
import net.minecraft.block.Block;
import net.minecraft.block.Blocks;
import net.minecraft.item.BlockItem;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public final class InfiniteEnchants implements ModInitializer {
    public static final String MOD_ID = "infiniteenchants";

    public static final Item ARCANE_CRYSTAL = Registry.register(
            Registries.ITEM,
            id("arcane_crystal"),
            new Item(new Item.Settings())
    );

    public static final Block ARCANE_ENCHANTING_ALTAR = Registry.register(
            Registries.BLOCK,
            id("arcane_enchanting_altar"),
            new Block(AbstractBlock.Settings.copy(Blocks.ENCHANTING_TABLE).strength(5.0f))
    );

    public static final Item ARCANE_ENCHANTING_ALTAR_ITEM = Registry.register(
            Registries.ITEM,
            id("arcane_enchanting_altar"),
            new BlockItem(ARCANE_ENCHANTING_ALTAR, new Item.Settings())
    );

    @Override
    public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.INGREDIENTS)
                .register(entries -> entries.add(ARCANE_CRYSTAL));

        ItemGroupEvents.modifyEntriesEvent(ItemGroups.FUNCTIONAL)
                .register(entries -> entries.add(ARCANE_ENCHANTING_ALTAR_ITEM));
    }

    public static Identifier id(String path) {
        return Identifier.of(MOD_ID, path);
    }
}
